package com.mandala.smartkey.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.mandala.smartkey.Models.GetNotif;
import com.mandala.smartkey.R;

import java.util.List;

public class NotifAdapter extends BaseAdapter {
    Context mContext;
    private List<GetNotif> mContact;
    RecyclerView.ViewHolder vh = null;

//Constructor


    public NotifAdapter(List<GetNotif> mContact, Context context) {

        this.mContact = mContact;
        this.mContext = context;
    }


    public class ViewHolder {

        public TextView tvMess;
        public TextView tvTgl;
        public TextView tvNo;

    }


    @Override
    public int getCount() {
        return mContact.size();
    }

    @Override
    public Object getItem(int position) {
        return mContact.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {

        View vi = convertView;
        ViewHolder holder;

        if (convertView == null) {

            LayoutInflater inflater;
            inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            vi = inflater.inflate(R.layout.listview_notif, null);

            holder = new ViewHolder();

            holder.tvMess = (TextView) vi.findViewById(R.id.tvMessage);
            holder.tvTgl = (TextView) vi.findViewById(R.id.tvTgl);
            holder.tvNo = (TextView) vi.findViewById(R.id.tvNo);


            vi.setTag(holder);

        } else
            holder = (ViewHolder) vi.getTag();

        // now set your text view here like

        // holder.tvName.setText("Bla Bla Bla");

        holder.tvMess.setText(mContact.get(position).getMessage());
        holder.tvTgl.setText(mContact.get(position).getTgl_mess());
        holder.tvNo.setText(mContact.get(position).getRownum());


        // return your view
        return vi;

    }
}
