package com.mandala.smartkey.Models;

import com.google.gson.annotations.SerializedName;

public class GetNotif {
    @SerializedName("data")
    private String data;
    @SerializedName("id_notif")
    private String id_notif;
    @SerializedName("tgl_mess")
    private String tgl_mess;
    @SerializedName("message")
    private String message;
    @SerializedName("rownum")
    private String rownum;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getId_notif() {
        return id_notif;
    }

    public void setId_notif(String id_notif) {
        this.id_notif = id_notif;
    }

    public String getTgl_mess() {
        return tgl_mess;
    }

    public void setTgl_mess(String tgl_mess) {
        this.tgl_mess = tgl_mess;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getRownum() {
        return rownum;
    }

    public void setRownum(String rownum) {
        this.rownum = rownum;
    }
}
