package com.mandala.smartkey;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NotifDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notif_detail);
    }
}