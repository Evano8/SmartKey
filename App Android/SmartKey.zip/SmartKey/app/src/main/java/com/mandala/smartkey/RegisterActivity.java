package com.mandala.smartkey;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;
import com.mandala.smartkey.util.api.BaseApiService;
import com.mandala.smartkey.util.api.UtilsApi;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.ContentValues.TAG;

public class RegisterActivity extends AppCompatActivity {
    private EditText editTextEmail;
    private EditText editTextPass;
    private EditText editTextNama;
    private EditText editTextKode;
    ProgressDialog loading;
    BaseApiService mApiService;
    String token;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_register);

        mApiService = UtilsApi.getAPIService(); // meng-init yang ada di packag

        Button regBtn = (Button) findViewById(R.id.buttonRegister);
        Button loginBtn = (Button) findViewById(R.id.buttonLogin);

        editTextNama = (EditText) findViewById(R.id.regTextNama);
        editTextKode = (EditText) findViewById(R.id.regTextKodeDevice);
        editTextEmail = (EditText) findViewById(R.id.regTextEmail);
        editTextPass = (EditText) findViewById(R.id.regTextPass);

        String deviceToken = FirebaseInstanceId.getInstance().getToken();
        Log.d(TAG,"Token: " +deviceToken);

        regBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Finally we need to implement a method to store this unique id to our server
                if (editTextNama.getText().toString().equals("")) {
                    editTextNama.setError("Nama Lengkap Tidak boleh kosong");
                } else if (editTextKode.getText().toString().equals("")) {
                    editTextKode.setError("Kode Modul Tidak boleh kosong");
                }else if (editTextEmail.getText().toString().equals("")) {
                    editTextEmail.setError("Email Tidak boleh kosong");
                }else if (editTextPass.getText().toString().equals("")) {
                    editTextPass.setError("Password Tidak boleh kosong");
                } else {
//                    String deviceToken = FirebaseMessaging.getInstance().getToken().toString();

                    sendIdToServer(deviceToken);
                }

            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    private void sendIdToServer(final String deviceToken) {
        loading = ProgressDialog.show(this, null, "Harap Tunggu...", true, false);
        mApiService.registerRequest(deviceToken,
                editTextNama.getText().toString(),
                editTextKode.getText().toString(),
                editTextEmail.getText().toString(),
                editTextPass.getText().toString())
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        loading.dismiss();
                        if (response.isSuccessful()){

                            try {
                                JSONObject jsonRESULTS = new JSONObject(response.body().string());
                                if (jsonRESULTS.getString("error").equals("false")){
                                    String message = jsonRESULTS.getString("message");
                                    Toast.makeText(RegisterActivity.this, message, Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                                    startActivity(intent);
                                } else {
                                    // Jika login gagal
                                    String error_message = jsonRESULTS.getString("message");
                                    Toast.makeText(RegisterActivity.this, error_message, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException | IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("debug", "onFailure: ERROR > " + t.toString());
                        Toast.makeText(RegisterActivity.this, "Koneksi Internet Bermasalah", Toast.LENGTH_SHORT).show();
                        loading.dismiss();
                    }
                });

    }
}