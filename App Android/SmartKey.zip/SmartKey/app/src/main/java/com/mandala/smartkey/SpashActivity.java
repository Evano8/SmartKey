package com.mandala.smartkey;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.mandala.smartkey.util.SharedPrefManager;

public class SpashActivity extends AppCompatActivity {
    SharedPrefManager sharedPrefManager;
    SharedPreferences sharedPreferences;
    Animation fromtop, frombottom;
    String res = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_spash);

        ImageView lv1 = (ImageView) findViewById(R.id.logo);
        TextView lv2 = (TextView) findViewById(R.id.splashimg);

        fromtop = AnimationUtils.loadAnimation(this, R.anim.fromtop);
        frombottom = AnimationUtils.loadAnimation(this, R.anim.frombottom);
        lv2.setAnimation(frombottom);
        lv1.setAnimation(fromtop);

        sharedPreferences = getSharedPreferences(SharedPrefManager.SP_APP, MODE_PRIVATE);
        sharedPrefManager = new SharedPrefManager(this);

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                //CEK SESSION LOGIN
                if (sharedPrefManager.getSPSudahLogin()){ //JIKA SESSION LOGIN == spSudahLogin KE MAIN ACTIVITY/HOME
                    startActivity(new Intent(SpashActivity.this, MainActivity.class)
                            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK));
                    finish();
                }else{//JIKA SESSION LOGIN == NULL KE MENU LOGIN
                    startActivity(new Intent(SpashActivity.this, LoginActivity.class)
                            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK));
                    finish();
                }
            }
        }, 5000 );//time in milisecond


    }
}