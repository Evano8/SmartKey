package com.mandala.smartkey.layout;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.firebase.iid.FirebaseInstanceId;
import com.mandala.smartkey.R;
import com.mandala.smartkey.util.SharedPrefManager;
import com.mandala.smartkey.util.api.BaseApiService;
import com.mandala.smartkey.util.api.UtilsApi;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {
    private static final String TAG = "";
    String nama_user,id_device,status_post,status_device,status_buzzer,status_sen;
    private TextView tvResultNama,tvResultStatus,edIdDevice,txtStatusSen;
    private ImageButton btn_on_off,btn_mute,btn_unmute;

    SharedPrefManager sharedPrefManager;
    HomeFragment mContext;
    BaseApiService mApiService;
    ProgressDialog loading;
    Handler mHandler;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, null);

        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Home");

        mContext = this;
        mApiService = UtilsApi.getAPIService();

        String deviceToken = FirebaseInstanceId.getInstance().getToken();
        Log.d(TAG,"Token: " +deviceToken);

        tvResultNama = (TextView) root.findViewById(R.id.textDeviceName);
        tvResultStatus = (TextView) root.findViewById(R.id.tvResultStatus);
        edIdDevice = (TextView) root.findViewById(R.id.txtIdDevice);
        txtStatusSen = (TextView) root.findViewById(R.id.txtStatusSen);

        sharedPrefManager = new SharedPrefManager(getActivity());
        nama_user = sharedPrefManager.getSPNama();
        id_device = sharedPrefManager.getSpDeviceid();

        edIdDevice.setText(id_device);

        this.mHandler = new Handler();


        //AKSI ON OFF
        btn_on_off = (ImageButton)root.findViewById(R.id.btnOnOff);
        btn_on_off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestonOff();
            }
        });

        //AKSI MUTE
        btn_mute = (ImageButton)root.findViewById(R.id.btnKlaksonOff);
        btn_mute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestKlaksonOff();
            }
        });
        //AKSI MUTE
        btn_unmute = (ImageButton)root.findViewById(R.id.btnKlaksonOn);
        btn_unmute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestKlaksonOn();
            }
        });
        getCekDevice();


        return root;
    }



    private void getCekDevice() {
        mApiService.cekDevice(edIdDevice.getText().toString())
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()){
                            try {
                                JSONObject jsonRESULTS = new JSONObject(response.body().string());
                                if (jsonRESULTS.getString("error").equals("false")){
                                    String merek_kendaraan = jsonRESULTS.getJSONObject("data").getString("merek_kendaraan");
                                    String status_name = jsonRESULTS.getJSONObject("data").getString("status_name");
                                    String status_device = jsonRESULTS.getJSONObject("data").getString("status_device");
                                    String status_buzzer = jsonRESULTS.getJSONObject("data").getString("status_buzzer");
                                    String status_sen = jsonRESULTS.getJSONObject("data").getString("status_sen");
                                    sharedPrefManager.saveSPString(SharedPrefManager.SP_STATUS_DEVICE, status_device);
                                    sharedPrefManager.saveSPString(SharedPrefManager.SP_STATUS_BUZZER, status_buzzer);

                                    txtStatusSen.setText(status_sen);
                                    tvResultNama.setText(merek_kendaraan);
                                    tvResultNama.setVisibility(View.VISIBLE);
                                    tvResultStatus.setText(status_name);

                                    if (status_device.equals("1"))
                                        btn_on_off.setBackgroundResource(R.drawable.btnon);
                                    else{
                                        btn_on_off.setBackgroundResource(R.drawable.btnoff);
                                    }

                                } else {
                                    // Jika login gagal
                                    String error_message = jsonRESULTS.getString("error_msg");
                                    Toast.makeText(getContext(), error_message, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException | IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("debug", "onFailure: ERROR > " + t.toString());
                        Toast.makeText(getContext(), "Koneksi Internet Bermasalah", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void requestonOff() {
        loading = ProgressDialog.show(getActivity(), null, "Harap Tunggu...", true, false);
        status_device = sharedPrefManager.getSpStatusDevice();
        if (status_device.equals("1")) {
            status_post = String.valueOf('0');
        }else{
            status_post = String.valueOf('1');
        }
        mApiService.getOnOff(edIdDevice.getText().toString(),status_post)
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()){
                            loading.dismiss();
                            try {
                                JSONObject jsonRESULTS = new JSONObject(response.body().string());
                                if (jsonRESULTS.getString("error").equals("false")){
                                    //requestUnMute();
                                    onSend();
                                    getCekDevice();
                                } else {
                                    // Jika login gagal
                                    String error_message = jsonRESULTS.getString("mess");
                                    Toast.makeText(getContext(), error_message, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException | IOException e) {
                                e.printStackTrace();
                            }
                        } else {
                            loading.dismiss();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("debug", "onFailure: ERROR > " + t.toString());
                        Toast.makeText(getContext(), "Koneksi Internet Bermasalah", Toast.LENGTH_SHORT).show();
                        loading.dismiss();
                    }
                });
    }

    private void onSend() {
        status_sen = String.valueOf('1');
        mApiService.updateSen(edIdDevice.getText().toString(),status_sen)
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()){
                            loading.dismiss();
                            try {
                                JSONObject jsonRESULTS = new JSONObject(response.body().string());
                                if (jsonRESULTS.getString("error").equals("false")){

                                    final Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            offSend();
                                        }
                                    }, 1000);

                                } else {
                                    // Jika login gagal
                                    String error_message = jsonRESULTS.getString("mess");
                                    Toast.makeText(getContext(), error_message, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException | IOException e) {
                                e.printStackTrace();
                            }
                        } else {
                            loading.dismiss();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("debug", "onFailure: ERROR > " + t.toString());
                        Toast.makeText(getContext(), "Koneksi Internet Bermasalah", Toast.LENGTH_SHORT).show();
                        loading.dismiss();
                    }
                });
    }

    private void offSend() {
        status_sen = String.valueOf('0');
        mApiService.updateSen(edIdDevice.getText().toString(),status_sen)
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()){
                            loading.dismiss();
                            try {
                                JSONObject jsonRESULTS = new JSONObject(response.body().string());
                                if (jsonRESULTS.getString("error").equals("false")){

                                    final Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            offSend();
                                        }
                                    }, 1000);

                                } else {
                                    // Jika login gagal
                                    String error_message = jsonRESULTS.getString("mess");
                                    Toast.makeText(getContext(), error_message, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException | IOException e) {
                                e.printStackTrace();
                            }
                        } else {
                            loading.dismiss();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("debug", "onFailure: ERROR > " + t.toString());
                        Toast.makeText(getContext(), "Koneksi Internet Bermasalah", Toast.LENGTH_SHORT).show();
                        loading.dismiss();
                    }
                });
    }

    private void requestKlaksonOn() {
        loading = ProgressDialog.show(getActivity(), null, "Harap Tunggu...", true, false);
        status_buzzer = String.valueOf('1');
        mApiService.getBuzzer(edIdDevice.getText().toString(),status_buzzer)
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()){
                            loading.dismiss();
                            try {
                                JSONObject jsonRESULTS = new JSONObject(response.body().string());
                                if (jsonRESULTS.getString("error").equals("false")){

                                    final Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            requestKlaksonOff();
                                        }
                                    }, 1000);
                                    getCekDevice();
                                    onSend();

                                } else {
                                    // Jika login gagal
                                    String error_message = jsonRESULTS.getString("mess");
                                    Toast.makeText(getContext(), error_message, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException | IOException e) {
                                e.printStackTrace();
                            }
                        } else {
                            loading.dismiss();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("debug", "onFailure: ERROR > " + t.toString());
                        Toast.makeText(getContext(), "Koneksi Internet Bermasalah", Toast.LENGTH_SHORT).show();
                        loading.dismiss();
                    }
                });
    }

    private void requestKlaksonOff() {
        loading = ProgressDialog.show(getActivity(), null, "Harap Tunggu...", true, false);
        status_buzzer = String.valueOf('0');
        mApiService.getBuzzer(edIdDevice.getText().toString(),status_buzzer)
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()){
                            loading.dismiss();
                            try {
                                JSONObject jsonRESULTS = new JSONObject(response.body().string());
                                if (jsonRESULTS.getString("error").equals("false")){
                                    final Handler handler = new Handler();
                                    onSend();
                                    getCekDevice();
                                } else {
                                    // Jika login gagal
                                    String error_message = jsonRESULTS.getString("mess");
                                    Toast.makeText(getContext(), error_message, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException | IOException e) {
                                e.printStackTrace();
                            }
                        } else {
                            loading.dismiss();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("debug", "onFailure: ERROR > " + t.toString());
                        Toast.makeText(getContext(), "Koneksi Internet Bermasalah", Toast.LENGTH_SHORT).show();
                        loading.dismiss();
                    }
                });
    }
}