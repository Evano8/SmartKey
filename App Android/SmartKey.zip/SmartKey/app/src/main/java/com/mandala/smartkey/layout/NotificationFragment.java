package com.mandala.smartkey.layout;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.mandala.smartkey.Adapter.NotifAdapter;
import com.mandala.smartkey.MainActivity;
import com.mandala.smartkey.Models.GetNotif;
import com.mandala.smartkey.R;
import com.mandala.smartkey.util.SharedPrefManager;
import com.mandala.smartkey.util.api.BaseApiService;
import com.mandala.smartkey.util.api.UtilsApi;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotificationFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener{
    SharedPrefManager sharedPrefManager;
    String id_device;

    private TextView tvBelumAda,edIdDevice,no_mess;
    private ListView listView;
    private List<GetNotif> contacts;
    private NotifAdapter adapter;
    private SwipeRefreshLayout swip;

    BaseApiService mApiService;
    Context mContext;
    ProgressDialog loading;
    AlertDialog.Builder builder;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_notifications, null);

        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Notifikasi");

        sharedPrefManager = new SharedPrefManager(getActivity());
        tvBelumAda = (TextView)root.findViewById(R.id.tvBelumMess);
        edIdDevice = (TextView) root.findViewById(R.id.txtIdDevice);
        no_mess = (TextView) root.findViewById(R.id.tvBelumMess);

        swip = (SwipeRefreshLayout) root.findViewById(R.id.swipNotif);
        swip.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                // Handler untuk menjalankan jeda selama 5 detik
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        // Berhenti berputar/refreshing
                        swip.setRefreshing(false);
                    }
                }, 2000);
            }
        });

        id_device = sharedPrefManager.getSpDeviceid();

        edIdDevice.setText(id_device);

//        listView.setTextFilterEnabled(true);

        mApiService = UtilsApi.getAPIService();
        mContext = getContext();

        sharedPrefManager = new SharedPrefManager(getActivity());

        listView = (ListView)root.findViewById(R.id.lv);


        getJSONResponse();

        return root;
    }


    private void getJSONResponse(){

        mApiService.getNotif(edIdDevice.getText().toString())
                .enqueue(new Callback<List<GetNotif>>() {
                    @Override
                    public void onResponse(Call<List<GetNotif>> call, Response<List<GetNotif>> response) {
                        contacts = response.body();
                        adapter = new NotifAdapter(contacts,getActivity());
                        if(contacts.equals("")){
                            no_mess.setVisibility(View.VISIBLE);
                        }else{

                            listView.setAdapter(adapter);
                        }



                }

                    @Override
                    public void onFailure(Call<List<GetNotif>> call, Throwable t) {
                        Log.e("debug", "onFailure: ERROR > " + t.toString());
                        Toast.makeText(getContext(), "Koneksi Internet Bermasalah", Toast.LENGTH_SHORT).show();
                    }

                });
    }

    @Override
    public void onRefresh() {
        Toast.makeText(getActivity(), "Please Wait", Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                //new Notif().execute();
                contacts.clear();
                adapter.notifyDataSetChanged();
                swip.setRefreshing(false);
            }
        }, 5000);
    }
}