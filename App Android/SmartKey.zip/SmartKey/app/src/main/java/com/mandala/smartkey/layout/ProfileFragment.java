package com.mandala.smartkey.layout;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.mandala.smartkey.LoginActivity;
import com.mandala.smartkey.R;
import com.mandala.smartkey.util.SharedPrefManager;
import com.mandala.smartkey.util.api.BaseApiService;
import com.mandala.smartkey.util.api.UtilsApi;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.MODE_PRIVATE;

public class ProfileFragment extends Fragment {
    private Button btnLogout,bt_update;
    SharedPrefManager sharedPrefManager;
    SharedPreferences sharedPreferences;
    Context mContext;
    BaseApiService mApiService;
    Handler mHandler;

    String id_device,id_user;

    private EditText et_first_name,et_username,et_merek,et_nopol,et_model;
    private TextView txtIdUser;

    ProgressDialog loading;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_profile, null);

        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Profile");

        sharedPreferences = getContext().getSharedPreferences(SharedPrefManager.SP_APP, MODE_PRIVATE);
        mContext = getActivity();
        mApiService = UtilsApi.getAPIService(); // meng-init yang ada di package apihelper
        sharedPrefManager = new SharedPrefManager(getActivity());



        id_device = sharedPrefManager.getSpDeviceid();
        id_user = sharedPrefManager.getSpUserid();

        txtIdUser = (TextView) root.findViewById(R.id.txtIdUser);
        txtIdUser.setText(id_user);

        et_first_name = (EditText)root.findViewById(R.id.et_first_name);
        et_username = (EditText)root.findViewById(R.id.et_username);
        et_merek = (EditText)root.findViewById(R.id.et_merek);
        et_nopol = (EditText)root.findViewById(R.id.et_nopol);
        et_model = (EditText)root.findViewById(R.id.et_model);


        //AKSI LOGOUT

        btnLogout = (Button)root.findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sharedPrefManager.saveSPBoolean(SharedPrefManager.SP_SUDAH_LOGIN, false);
                startActivity(new Intent(getActivity(), LoginActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK));
            }
        });

        //UPDATE
        bt_update = (Button)root.findViewById(R.id.bt_update);
        bt_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestUpdate();
            }
        });
        getCekProfile();
        return root;
    }

    private void getCekProfile() {
        mApiService.cekProfile(txtIdUser.getText().toString())
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()){
                            try {
                                JSONObject jsonRESULTS = new JSONObject(response.body().string());
                                if (jsonRESULTS.getString("error").equals("false")){
                                    String nama_lengkap = jsonRESULTS.getJSONObject("data").getString("nama_lengkap");
                                    String username = jsonRESULTS.getJSONObject("data").getString("email");
                                    String merek_kendaraan = jsonRESULTS.getJSONObject("data").getString("merek_kendaraan");
                                    String nopol = jsonRESULTS.getJSONObject("data").getString("nopol");
                                    String model_kendaraan = jsonRESULTS.getJSONObject("data").getString("model_kendaraan");

                                    et_first_name.setText(nama_lengkap);
                                    et_username.setText(username);
                                    et_merek.setText(merek_kendaraan);
                                    et_nopol.setText(nopol);
                                    et_model.setText(model_kendaraan);


                                } else {
                                    // Jika login gagal
                                    String error_message = jsonRESULTS.getString("error_msg");
                                    Toast.makeText(getContext(), error_message, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException | IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("debug", "onFailure: ERROR > " + t.toString());
                        Toast.makeText(getContext(), "Koneksi Internet Bermasalah", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void requestUpdate() {
        loading = ProgressDialog.show(getActivity(), null, "Harap Tunggu...", true, false);

        mApiService.getUpdateProfile(txtIdUser.getText().toString(),
                        id_device,
                        et_first_name.getText().toString(),
                        et_username.getText().toString(),
                        et_merek.getText().toString(),
                        et_nopol.getText().toString(),
                        et_model.getText().toString())
                .enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        if (response.isSuccessful()){
                            loading.dismiss();
                            try {
                                JSONObject jsonRESULTS = new JSONObject(response.body().string());
                                if (jsonRESULTS.getString("error").equals("false")){
                                    getCekProfile();
                                } else {
                                    // Jika login gagal
                                    String error_message = jsonRESULTS.getString("mess");
                                    Toast.makeText(getContext(), error_message, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException | IOException e) {
                                e.printStackTrace();
                            }
                        } else {
                            loading.dismiss();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        Log.e("debug", "onFailure: ERROR > " + t.toString());
                        Toast.makeText(getContext(), "Koneksi Internet Bermasalah", Toast.LENGTH_SHORT).show();
                        loading.dismiss();
                    }
                });
    }
}