package com.mandala.smartkey.util;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.RemoteMessage;
import com.mandala.smartkey.MainActivity;
import com.mandala.smartkey.NotifDetailActivity;
import com.mandala.smartkey.R;

import java.text.SimpleDateFormat;

public class FCMService extends com.google.firebase.messaging.FirebaseMessagingService {
    View view;
    SharedPreferences sharedPreferences;
    public static final String mypreferenced = "myprefs";
    String dateString;
    private SimpleDateFormat dateFormter;
    String im;
    private long time;
    Context context;

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {

        showNotification(remoteMessage.getData().get("message"));

        }

    private void showNotification(String message){
        Intent i = new Intent(this, NotifDetailActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(this,0,i,PendingIntent.
                FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                .setAutoCancel(true)
                .setContentTitle("SmartKey")
                .setContentText(message)
                .setSmallIcon(R.drawable.logo)
                .setContentIntent(pendingIntent);

        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.notify(0,builder.build());
    }

}
