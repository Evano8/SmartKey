package com.mandala.smartkey.util;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefManager {
    public static final String SP_APP = "spEarlyWarningSecurityApp";

    public static final String SP_NAMA = "nama_lengkap";
    public static final String SP_DEVICEID = "id_device";
    public static final String SP_USERID = "id_user";
    public static final String SP_TOKEN = "token";
    public static final String SP_STATUS_DEVICE = "status_device";
    public static final String SP_STATUS_BUZZER = "status_buzzer";
    public static final String KEY_ID_NOTIF = "id_notif";
    public static final String KEY_PESAN = "message";
    public static final String KEY_TGL_PESAN = "tgl_mess";

    public static final String SP_SUDAH_LOGIN = "spSudahLogin";

    SharedPreferences sp;
    SharedPreferences.Editor spEditor;

    public SharedPrefManager(Context context){
        sp = context.getSharedPreferences(SP_APP, Context.MODE_PRIVATE);
        spEditor = sp.edit();
    }

    public void saveSPString(String keySP, String value){
        spEditor.putString(keySP, value);
        spEditor.commit();
    }

    public void saveSPInt(String keySP, int value){
        spEditor.putInt(keySP, value);
        spEditor.commit();
    }

    public void saveSPBoolean(String keySP, boolean value){
        spEditor.putBoolean(keySP, value);
        spEditor.commit();
    }

    public String getSPNama(){
        return sp.getString(SP_NAMA, "");
    }

    public String getSpDeviceid(){
        return sp.getString(SP_DEVICEID, "");
    }

    public String getSpUserid(){
        return sp.getString(SP_USERID, "");
    }
    public String getSpToken(){
        return sp.getString(SP_TOKEN, "");
    }

    public String getSpStatusDevice(){
        return sp.getString(SP_STATUS_DEVICE, "");
    }

    public String getSpStatusBuzzer(){
        return sp.getString(SP_STATUS_BUZZER, "");
    }

    public String KEY_ID_NOTIF(){
        return sp.getString(KEY_ID_NOTIF, "");
    }

    public String KEY_PESAN(){
        return sp.getString(KEY_PESAN, "");
    }
    public String KEY_TGL_PESAN(){
        return sp.getString(KEY_TGL_PESAN, "");
    }

    public Boolean getSPSudahLogin(){
        return sp.getBoolean(SP_SUDAH_LOGIN, false);
    }
}
