package com.mandala.smartkey.util.api;

import com.mandala.smartkey.Models.GetNotif;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface BaseApiService {
    //LOGIN
    @FormUrlEncoded
    @POST("api_c/respon_login")
    Call<ResponseBody> loginRequest(@Field("username") String username,
                                    @Field("password") String password);
    //DAFTAR
    @FormUrlEncoded
    @POST("api_c/register")
    Call<ResponseBody> registerRequest(@Field("token") String token,
                                       @Field("nama") String nama,
                                       @Field("device_name") String device_name,
                                       @Field("email") String email,
                                    @Field("password") String password);

    //CEK DEVICE
    @FormUrlEncoded
    @POST("api_c/cek_device")
    Call<ResponseBody> cekDevice(@Field("id_device") String id_device);
    //UPDATE ALARM
    @FormUrlEncoded
    @POST("api_c/update_status_device")
    Call<ResponseBody> getOnOff(@Field("id_device") String id_device,
                                @Field("status") String status);
    //UPDATE KLAKSON
    @FormUrlEncoded
    @POST("api_c/update_status_buzzer")
    Call<ResponseBody> getBuzzer(@Field("id_device") String id_device,
                                 @Field("status_buzzer") String status_buzzer);

    //UPDATE SEN
    @FormUrlEncoded
    @POST("api_c/update_status_sen")
    Call<ResponseBody> updateSen(@Field("id_device") String id_device,
                                 @Field("status_sen") String status_sen);


    //CEK PROFILE
    @FormUrlEncoded
    @POST("api_c/cek_profile")
    Call<ResponseBody> cekProfile(@Field("id_user") String id_user);

    @FormUrlEncoded
    @POST("api_c/update_profile")
    Call<ResponseBody> getUpdateProfile(
            @Field("id_user") String id_user,
            @Field("id_device") String id_device,
            @Field("nama_lengkap") String nama_lengkap,
            @Field("username") String username,
            @Field("merek_kendaraan") String merek_kendaraan,
            @Field("nopol") String nopol,
            @Field("model_kendaraan") String model_kendaraan);

    //LIST NOTIF
    @FormUrlEncoded
    @POST("api_c/get_notif")
    Call<List<GetNotif>> getNotif(@Field("id_device") String id_device);


}
