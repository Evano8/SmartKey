package com.mandala.smartkey.util.api;

public class UtilsApi {
    public static final String BASE_URL_API = "https://skripsimandala.afifawater.com/";

    // Mendeklarasikan Interface BaseApiService
    public static BaseApiService getAPIService(){
        return ApiClient.getClient(BASE_URL_API).create(BaseApiService.class);
    }
}
