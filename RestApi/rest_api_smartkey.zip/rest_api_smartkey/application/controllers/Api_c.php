<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api_c extends CI_Controller {

	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Api_m');  
		$this->load->database(); 
		$this->load->helper('string'); 
		$this->ci = & get_instance();
		header("Content-Type: application/json;charset=utf-8");
	}
	
	//LOGIN	 
	public function respon_login(){
			
			$username = $this->input->post('username');
			$password = md5($this->input->post('password'));
			$data = array();
			if((strlen($username) > 0) AND (strlen($password) >0)){
				//cek username dan pwd
				if ($user = $this->ci->Api_m->get_login($username)) {
					//print_r($user);
							
					if ($user['password'] == $password) { 
						$this->ci->session->set_userdata(array(
							'id_user'	=> $user['id_user'],
							'nama_lengkap'	=> $user['nama_lengkap'],
							'email'   => $user['email'],
							'password'   => $user['password'],
							'id_device'   => $user['id_device'],
							'token'   => $user['token'],
							'isLoggedIn'=>true
						));
						
						if($user['status'] == 0){
							$data['error'] = true;
							$data['message'] = 'Status user Non Active';
							return false;
						}else{
							$id_user =$this->session->userdata['id_user'];
							$nama_lengkap =$this->session->userdata['nama_lengkap'];
							$email =$this->session->userdata['email'];
							$id_device =$this->session->userdata['id_device'];
							$token =$this->session->userdata['token'];
							//$kodeToken =  random_string('numeric', 6);
 
							$data['error'] = false;
							$data['message'] = 'Berhasil Login';
							$data['user'] = array(
                				'id_user' => $id_user,
    							'nama_lengkap' => $nama_lengkap,
    							'email' => $email,
    							'id_device' => $id_device,
    							'token' => $token,
                			);
							
						}
					}else{
						$data['error'] = true;
					 	$data['message'] = 'Password Salah';
					}
					
				}else{
					$data['error'] = true;
					$data['message'] = 'Username tidak terdaftar';
				}
				
			}else{
				$data['error'] = true;
				$data['message'] = 'Username atau password tidak boleh kosong';
			}
		echo json_encode($data);
	}
	//DAFTAR
	public function register(){
		$nama = $this->input->post('nama');
		$device_name = $this->input->post('device_name');
		$email = $this->input->post('email');
		$password = md5($this->input->post('password'));
		$token = $this->input->post('token');
		echo $this->ci->Api_m->register($nama,$device_name,$email,$password,$token);		
		
	}
	//LOGOUT
	public function logout()
	{
		
		$this->session->sess_destroy();
		$this->load->helper('cookie');
		delete_cookie("api_skripsi");
		delete_cookie("PHPSESSID");
		$data['status']='success';
		$data['mess']='Berhasil keluar system';
		echo json_encode($data);
		
		
	}
	//=================HOME===============
	//CEK KONDISI WEMOS
	public function cek_device()
	{
		
			$id_device = $this->input->post('id_device');
			$data = array();
			if((strlen($id_device) > 0)){
				$getData = $this->ci->Api_m->cek_device($id_device);
				if($getData['status_device'] == 1){
					$status_name = "Alarm Aktif";
				}else{
					$status_name = "Alarm Off";
				}
				$data['error'] = false;
				$data['message'] = 'success';
				$data['data'] = array(
					'id_device' => $getData['id_device'],
					'name_device' => $getData['name_device'],
					'status_device' => $getData['status_device'],
					'status_buzzer' => $getData['status_buzzer'],
					'status_sen' => $getData['status_sen'],
					'status_name' => $status_name,
					'merek_kendaraan' => $getData['merek_kendaraan'],
					'model_kendaraan' => $getData['model_kendaraan'],
					'nopol' => $getData['nopol']
				);
				
				
				 
		}else{
			$data['error'] = true;
			$data['message'] = 'device tidak tidak ditemukan';
			$data['data'] = '';
		}
		
		echo json_encode($data);

	}
	
	// CEK STATUS AWAL WEMOS
	public function status_device($id_device)
	{ 
		if((strlen($id_device) > 0)){ 
				//cek username dan pwd
				if ($getData = $this->ci->Api_m->cek_device($id_device)) {
					if($getData['status_device'] == 1){
						$status_name = "Alarm Aktif";
					}else{ 
						$status_name = "Alarm Off";
					}
					  
					$data['error'] = false;
					$data['message'] = 'success';
					$data['id_device'] = $getData['id_device'];
					$data['name_device'] = $getData['name_device'];
					$data['status_device'] = $getData['status_device'];
					$data['status_buzzer'] = $getData['status_buzzer'];
					$data['status_sen'] = $getData['status_sen'];
					$data['token'] = $getData['token'];
					$data['status_name'] = $status_name;
				}
			}else{
				$data['error'] = false;
				$data['message'] = 'error';
			}
		echo json_encode($data);

	}
	
	//UPDATE STATUS ALARM 
	public function update_status_device()
	{
		
		$id_device = $this->input->post('id_device');
		$status = $this->input->post('status');
		echo $this->Api_m->update_status_device($id_device,$status);

	}

	//UPDATE STATUS BUZZER
	public function update_status_buzzer()
	{
		
		$id_device = $this->input->post('id_device');
		$status_buzzer = $this->input->post('status_buzzer');
		echo $this->Api_m->update_status_buzzer($id_device,$status_buzzer);

	}

	public function update_status_sen()
	{
		
		$id_device = $this->input->post('id_device');
		$status_sen = $this->input->post('status_sen');
		echo $this->Api_m->update_status_sen($id_device,$status_sen);

	}

	//==============PROFILE===============
	//CEK DATA PROFILE
	public function cek_profile()
	{
		
			$id_user = $this->input->post('id_user');
			$data = array();
			if((strlen($id_user) > 0)){
				$getData = $this->ci->Api_m->cek_profile($id_user);
				
				$data['error'] = false;
				$data['message'] = 'success';
				$data['data'] = array(
					'nama_lengkap' => $getData['nama_lengkap'],
					'email' => $getData['email'],
					'merek_kendaraan' => $getData['merek_kendaraan'],
					'model_kendaraan' => $getData['model_kendaraan'],
					'nopol' => $getData['nopol']
				);
				
				
				 
		}else{
			$data['error'] = true;
			$data['message'] = 'device tidak tidak ditemukan';
			$data['data'] = '';
		}
		
		echo json_encode($data);

	}
	//UPDATE PROFILE
	public function update_profile()
	{
		
		$id_user = $this->input->post('id_user');
		$id_device = $this->input->post('id_device');
		$nama_lengkap = $this->input->post('nama_lengkap');
		$username = $this->input->post('username');
		$merek_kendaraan = $this->input->post('merek_kendaraan');
		$model_kendaraan = $this->input->post('model_kendaraan');
		$nopol = $this->input->post('nopol');
		echo $this->Api_m->update_profile($id_user,$id_device,$nama_lengkap,$username,$merek_kendaraan,$model_kendaraan,$nopol);

	}
	
	//===========NOTIFIKASI=============
	public function get_notif()
	{
		$id_device = $this->input->post('id_device');
		echo $this->Api_m->get_notif($id_device);
	}

	
	public function insert_mess($id_device) 
	{
		echo $this->Api_m->insert_mess($id_device);
	} 
 
	public function send_notif($token)
	{
		echo $this->Api_m->send_notif($token);
	}

	 
}