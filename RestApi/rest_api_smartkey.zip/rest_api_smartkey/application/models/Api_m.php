<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

Class Api_m extends CI_Model{
	private $ci;
	
	public function __construct() {
        parent::__construct();
        header("Content-Type: application/json;charset=utf-8");
		$this->load->helper('url');
		date_default_timezone_set("Asia/Bangkok");
    }
	
	
	public function execute($sql){
	   if (isset($sql)) {
			return $this->db->query($sql)->result();
		} 	
		return false;
	}
	
	public function outputJSON($data) {
		header("Content-Type: application/json;charset=utf-8");
		echo json_encode($data);
	}
	
	private function escape($value) {
		$return = '';
		for($i = 0; $i < strlen($value); ++$i) {
			$char = $value[$i];
			$ord = ord($char);
			if($char !== "'" && $char !== "\"" && $char !== '\\' && $ord >= 32 && $ord <= 126)
				$return .= $char;
			else
				$return .= '\\x' . dechex($ord);
		}
		return $return;
	} 
	//DAFTAR
	function register($nama,$device_name,$email,$password,$token){ 
		$cek_device = $this->db->query("SELECT * FROM device_modul where name_device='$device_name'");
		if ($cek_device->num_rows() == '0') {
			$res['error'] = true;
			$res['message']  = 'Kode device tidak terdaftar'; 
		}else{
			$cek_username = $this->db->query("SELECT * FROM users where email='$email'");
			
			if ($cek_username->num_rows() == '0') {
				foreach($cek_device->result() as $row){
					$id_device=$row->id_device;
					$sql="INSERT INTO users (token,email,password,nama_lengkap,status,id_device) VALUES ('$token','$email','$password','$nama','1','$id_device') ON DUPLICATE KEY UPDATE token = '$token'";
	
				}
				$rs = $this->db->query($sql);
				if($rs){
					$res['error'] = false;
					$res['message']  = 'Berhasil Daftar.'; 
				}else{
					$res['error'] = true;
					$res['message']  = 'Gagal Daftar'; 
				} 
				
			}else{
				$res['error'] = true;
				$res['message'] = 'Email Sudah Terdaftar';
			}
		}
		
		return json_encode($res);
	}
	//LOGIN
	public function get_login($username) {
	    $username = strtolower($this->escape($username));
		$data = array();
		if(strlen ($username)>0){
			$sql ="select * from users where email='$username'"; 
			$rs = $this->execute($sql);
			$len = 1; 
			$rows = array();
			foreach ($rs as $row)	   
			{
				$data= Array(
					  'id_user' => $row->id_user,
					  'nama_lengkap' => $row->nama_lengkap,
					  'email' => $row->email,
					  'password' => $row->password,
					  'id_device' => $row->id_device,
					  'token' => $row->token,
					  'status' => $row->status,
					  'rownum' =>$len
				);
				$len++;		 			
			}
			return $data;
		}else{
			return false;
		}
		
       
    }

	//=============HOME===================
    //CEK KONDISI WEMOS
    function cek_device($id_device){
		$id_device = strtolower($this->escape($id_device));
		$data = array();
		if(strlen ($id_device)>0){
			$sql ="SELECT a.*,b.token FROM device_modul a 
			LEFT JOIN users b ON b.id_device=a.id_device
			WHERE a.id_device='$id_device'"; 
			$rs = $this->execute($sql);
			$len = 1; 
			$rows = array();
			foreach ($rs as $row)	   
			{
				$data= Array(
					'id_device' => $row->id_device,
					'name_device' => $row->name_device,
					'merek_kendaraan' => $row->merek_kendaraan,
					'model_kendaraan' => $row->model_kendaraan,
					'nopol' => $row->nopol,
					'status_device' => $row->is_active,
					'status_buzzer' => $row->is_buzzer,
					'status_sen' => $row->is_sen,
					'token' => $row->token,
					'rownum' =>$len
				);
				$len++;		 			
			}
			return $data;
		}else{
			return false;
		}
		
		
	}

	//UPDATE STATUS ALARM
    function update_status_device($id_device,$status){
		$sql ="UPDATE `device_modul` SET is_active='$status' WHERE id_device='$id_device'"; 
		$rs = $this->db->query($sql);
		if($rs){
			$res['error'] = false;
			$res['mess']  = 'Berhasil Update data.'; 
		}else{
			$res['error'] = true;
			$res['mess']  = 'Gagal Update data.'; 
		} 
		return json_encode($res);
		
	}

	//UPDATE STATUS ALARM
    function update_status_buzzer($id_device,$status_buzzer){
		$sql ="UPDATE `device_modul` SET is_buzzer='$status_buzzer' WHERE id_device='$id_device'"; 
		$rs = $this->db->query($sql);
		if($rs){
			$res['error'] = false;
			$res['mess']  = 'Berhasil Update data.'; 
		}else{
			$res['error'] = true;
			$res['mess']  = 'Gagal Update data.'; 
		} 
		return json_encode($res);
		
	}

	//UPDATE SEN
    function update_status_sen($id_device,$status_sen){
		$sql ="UPDATE `device_modul` SET is_sen='$status_sen' WHERE id_device='$id_device'"; 
		$rs = $this->db->query($sql);
		if($rs){
			$res['error'] = false;
			$res['mess']  = 'Berhasil Update data.'; 
		}else{
			$res['error'] = true;
			$res['mess']  = 'Gagal Update data.'; 
		} 
		return json_encode($res);
		
	}
	
	//===========PROFILE==================
	function cek_profile($id_user){
		$id_user = strtolower($this->escape($id_user));
		$data = array();
		if(strlen ($id_user)>0){
			$sql ="SELECT a.*,b.merek_kendaraan,b.model_kendaraan,b.nopol FROM users a 
			LEFT JOIN device_modul b on b.id_device=a.id_device
			WHERE a.id_user='$id_user'"; 
			$rs = $this->execute($sql);
			$len = 1; 
			$rows = array();
			foreach ($rs as $row)	   
			{  
				$data= Array(
					'nama_lengkap' => $row->nama_lengkap,
					'email' => $row->email,
					'merek_kendaraan' => $row->merek_kendaraan,
					'model_kendaraan' => $row->model_kendaraan,
					'nopol' => $row->nopol,
					'rownum' =>$len
				);
				$len++;		 			
			}
			return $data;
		}else{
			return false;
		}
		
		
	}
	
	//UPDATE PROFILE
	function update_profile($id_user,$id_device,$nama_lengkap,$username,$merek_kendaraan,$model_kendaraan,$nopol){
		$sql ="UPDATE `users` SET nama_lengkap='$nama_lengkap',email='$username' WHERE id_user='$id_user'"; 
		$sql2 ="UPDATE `device_modul` SET merek_kendaraan='$merek_kendaraan',model_kendaraan='$model_kendaraan' ,nopol='$nopol'
		WHERE id_device='$id_device'"; 
		$this->db->query($sql);
		$rs = $this->db->query($sql2);
		if($rs){
			$res['error'] = false;
			$res['mess']  = 'Berhasil Update data.'; 
		}else{
			$res['error'] = true;
			$res['mess']  = 'Gagal Update data.'; 
		} 
		return json_encode($res);
		
	}
	
	//==========NOTIFIKASI===========
	public function get_notif($id_device){
		$sql ="SELECT * FROM notif WHERE id_device='$id_device'"; 
		$rs = $this->execute($sql);
		$len = 1; 
		$rows = array();
		foreach ($rs as $row)	   
		{
			$data[] = Array(
			    'id_notif' => $row->id_notif,
					'tgl_mess' => $row->tgl,
					'message' => $row->mess,
					'rownum' => $len,
				
			);
			$len++;
				
		}
		if (empty($data))
		  $data[]= Array(); 		
        return json_encode($data);
	}
	 
	//SEND NOTIFICATION TO FCM
	function send_notif($token){
		$curl = curl_init();

		curl_setopt_array($curl, array(
		CURLOPT_URL => 'https://fcm.googleapis.com/fcm/send',
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => 'POST',
		CURLOPT_POSTFIELDS =>'{
		"to" : "'.$token.'",
		"collapse_key" : "type_a",
		"notification" : {
			"body" : "Ada yang mencoba membuka paksa motor anda",
			"title": "SmartKey"
		},
		"data" : {
			"body" : "Ada yang mencoba membuka paksa motor anda",
			"title": "SmartKey",
			"key_1" : "Value for key_1",
			"key_2" : "Value for key_2"
		}
		}
		',
		CURLOPT_HTTPHEADER => array(
			'Authorization: key=AAAANrWJ-LU:APA91bHtUU7StY03TCezxbsPyQhl_snOADb7u0JZZzH-cPTe8TAlA5Vy2qABZGnw7nBmlyuXwA86Mvx9DHmZSMVdQ3-QpQH1W81XvUKWgyLo2lnpKNeXHcX7-bnZDAEFT0MJAjGXl0E5',
			'Content-Type: application/json'
		),
		));

		$response = curl_exec($curl);

		curl_close($curl);
		echo $response;

		
	}
	
	//insert data sensor pir
	public function insert_mess($id_device) {
		//$message = $this->input->post('message');
		$message = "Ada yang mencoba membuka paksa motor anda";
		$tgl_mess = date('Y-m-d H:i:s');
		$status_buzzer = "1"; 
		$sql ="INSERT INTO notif(tgl,mess,id_device) VALUES 
		('$tgl_mess','$message','$id_device')"; 
		$rs = $this->db->query($sql);
		if($rs){
			$res['status'] = 'success';
			$res['mess']  = 'Berhasil Simpan data.';
			//this->send_notif(); 
			$cek_token = $this->db->query("SELECT * FROM users where id_device='$id_device'")->row_array();
			$token =$cek_token['token'];
			$this->update_status_buzzer($id_device,$status_buzzer);
			$this->send_notif($token);
		}else{
			$res['status'] = 'failed';
			$res['mess']  = 'Gagal Simpan data.'; 
		} 
		return json_encode($res);
    }
	
	
}
?>