-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 02 Agu 2022 pada 18.29
-- Versi server: 10.5.15-MariaDB-cll-lve
-- Versi PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u1089044_earlywarning`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `device_modul`
--

CREATE TABLE `device_modul` (
  `id_device` int(11) NOT NULL,
  `name_device` varchar(100) NOT NULL,
  `merek_kendaraan` varchar(100) NOT NULL,
  `model_kendaraan` varchar(100) NOT NULL,
  `nopol` varchar(50) NOT NULL,
  `is_active` int(11) NOT NULL,
  `is_buzzer` int(11) NOT NULL,
  `is_sen` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `device_modul`
--

INSERT INTO `device_modul` (`id_device`, `name_device`, `merek_kendaraan`, `model_kendaraan`, `nopol`, `is_active`, `is_buzzer`, `is_sen`) VALUES
(1, 'SmartKey01', 'Yamaha Fino', 'Fino 125', 'B 4493 SGL', 1, 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `notif`
--

CREATE TABLE `notif` (
  `id_notif` int(11) NOT NULL,
  `tgl` datetime NOT NULL,
  `mess` text NOT NULL,
  `status_baca` int(11) NOT NULL,
  `id_device` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `notif`
--

INSERT INTO `notif` (`id_notif`, `tgl`, `mess`, `status_baca`, `id_device`) VALUES
(2, '2022-08-02 08:44:20', 'Ada yang mencoba membuka paksa motor anda', 0, 1),
(3, '2022-08-02 09:23:33', 'Ada yang mencoba membuka paksa motor anda', 0, 1),
(4, '2022-08-02 18:01:56', 'Ada yang mencoba membuka paksa motor anda', 0, 1),
(5, '2022-08-02 18:02:44', 'Ada yang mencoba membuka paksa motor anda', 0, 1),
(6, '2022-08-02 18:04:18', 'Ada yang mencoba membuka paksa motor anda', 0, 1),
(7, '2022-08-02 18:08:17', 'Ada yang mencoba membuka paksa motor anda', 0, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `id_device` int(11) NOT NULL,
  `token` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id_user`, `nama_lengkap`, `email`, `username`, `password`, `status`, `id_device`, `token`) VALUES
(12, 'Mugiwara ', 'dadangkurniawan54@gmail.com', '', 'e854211ace6904dc5b5d3e3c728f252e', 1, 1, 'cuOabghTRVWY63p4u3_0pH:APA91bEh42cTgk8Albx8TwqlOckkCRf5eVIriCfVD169huRqblFccupCusQIZ0lK9jAgzkYlBpB0LjwZMQjZJY9j4dc9Hw4yJ2eFPFbdys-5Ez-tr44Ri2AlTbfbKskX6IS-2sx6ZaG0'),
(13, 'Muchrian Mandala', 'muchrian0806@gmail.com', '', 'e10adc3949ba59abbe56e057f20f883e', 1, 1, 'cJ3jvBycILo:APA91bH_W1a8M5S6-6yaI8_VNBWImILNCYQloAQPjLmifdZX1PbWvLZ-nOmjJSqeJZxpGLINv7IZkqvnDi261PK1kMQYG4XfHshOq7LqdwhSt1QNlV537luRmxaK_UCReS8kOCQeMRD_'),
(14, 'mandala', 'muchrian.0909@gmail.com', '', 'e10adc3949ba59abbe56e057f20f883e', 1, 1, 'cJ3jvBycILo:APA91bH_W1a8M5S6-6yaI8_VNBWImILNCYQloAQPjLmifdZX1PbWvLZ-nOmjJSqeJZxpGLINv7IZkqvnDi261PK1kMQYG4XfHshOq7LqdwhSt1QNlV537luRmxaK_UCReS8kOCQeMRD_');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `device_modul`
--
ALTER TABLE `device_modul`
  ADD PRIMARY KEY (`id_device`);

--
-- Indeks untuk tabel `notif`
--
ALTER TABLE `notif`
  ADD PRIMARY KEY (`id_notif`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `device_modul`
--
ALTER TABLE `device_modul`
  MODIFY `id_device` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `notif`
--
ALTER TABLE `notif`
  MODIFY `id_notif` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
